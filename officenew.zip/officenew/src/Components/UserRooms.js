// import React, { useState, useEffect } from 'react';
// import '../Styles/roomseat.css'; // Import your external CSS file

// const Seat = ({ seatNumber, isSelected, onSelect }) => {
//   const handleClick = () => {
//     if (!isSelected) {
//       onSelect(seatNumber);
//     }
//   };

//   return (
//     <div
//       className={`seat ${isSelected ? 'selected' : ''}`}
//       onClick={handleClick}
//     >
//       {seatNumber}
//     </div>
//   );
// };

// const AddRooms = () => {
//   const [rows, setRows] = useState(3);
//   const [columns, setColumns] = useState(3);
//   const [selectedSeats, setSelectedSeats] = useState([]);
//   const [roomName, setRoomName] = useState('');
//   const [showRoomInfo, setShowRoomInfo] = useState(false); // State for displaying room info

//   const handleSeatSelect = (seatNumber) => {
//     // Check if the selected seat is already in the selectedSeats array
//     if (!selectedSeats.includes(seatNumber)) {
//       // Check if the current column has reached the maximum of 4 selected seats
//       const column = (seatNumber - 1) % columns;
//       const columnSelectedCount = selectedSeats.filter((seat) => (seat - 1) % columns === column).length;

//       if (columnSelectedCount < 4) {
//         setSelectedSeats([...selectedSeats, seatNumber]);
//       }
//     } else {
//       // If the seat is already selected, remove it from the selectedSeats array
//       setSelectedSeats(selectedSeats.filter((seat) => seat !== seatNumber));
//     }
//   };

//   const handleCreateRoom = () => {
//     if (selectedSeats.length > 0 && roomName.trim() !== '') {
//       setShowRoomInfo(true); // Show room info after creating the room
//     }
//   };

//   useEffect(() => {
//     // Simulate an API call to show selected seats
//     console.log('Selected seats:', selectedSeats);
//   }, [selectedSeats]);

//   // Calculate the total number of seats
//   const totalSeats = rows * columns;

//   return (
//     <div className="App">
//       <h1>Office Seat Booking</h1>
//       <div className="options">
//         <label>
//           Room Name:
//           <input
//             type="text"
//             placeholder="Enter Room Name"
//             value={roomName}
//             onChange={(e) => setRoomName(e.target.value)}
//           />
//         </label>
//         <label>
//           Rows:
//           <input
//             type="number"
//             value={rows}
//             onChange={(e) => setRows(Number(e.target.value))}
//           />
//         </label>
//         <label>
//           Columns:
//           <input
//             type="number"
//             value={columns}
//             onChange={(e) => setColumns(Number(e.target.value))}
//           />
//         </label>
//         <button onClick={() => setSelectedSeats([])}>Clear Selection</button>
//         <button onClick={handleCreateRoom}>Add Room</button>
//       </div>
//       <div className="seat-grid">
//         {Array.from({ length: rows }, (_, rowIndex) => (
//           <div key={rowIndex} className="seat-row">
//             {Array.from({ length: columns }, (_, colIndex) => {
//               const seatNumber = rowIndex * columns + colIndex + 1;
//               return (
//                 <Seat
//                   key={seatNumber}
//                   seatNumber={seatNumber}
//                   isSelected={selectedSeats.includes(seatNumber)}
//                   onSelect={handleSeatSelect}
//                 />
//               );
//             })}
//           </div>
//         ))}
//       </div>
//       {showRoomInfo && (
//         <div className="room-info">
//           <h2>Room Information</h2>
//           <p>Room Name: {roomName}</p>
//           <p>Rows: {rows}</p>
//           <p>Columns: {columns}</p>
//           <p>Total Seats: {totalSeats}</p>
//           <p>Selected Seats: {selectedSeats.join(', ')}</p>
//         </div>
//       )}
//     </div>
//   );
// };

// export default AddRooms;




import React, { useState } from 'react';
import '../Styles/roomseat.css'; // Import your external CSS file

const Seat = ({ seatNumber }) => {
  return (
    <div className="seat">
      {seatNumber}
    </div>
  );
};

const AddRooms = () => {
  const [rows, setRows] = useState(3);
  const [columns, setColumns] = useState(3);
  const [roomName, setRoomName] = useState('');
  const [roomInfo, setRoomInfo] = useState(null);

  const handleCreateRoom = () => {
    if (roomName.trim() !== '') {
      console.log('Creating room:', roomName);

      const seatStructure = [];
      for (let rowIndex = 0; rowIndex < rows; rowIndex++) {
        const row = [];
        for (let colIndex = 0; colIndex < columns; colIndex++) {
          const seatNumber = rowIndex * columns + colIndex + 1;
          row.push(seatNumber);
        }
        seatStructure.push(row);
      }

      setRoomInfo({
        roomName,
        rows,
        columns,
        seatStructure,
      });
    }
  };

  const renderSeatGrid = (seatStructure) => {
    return seatStructure.map((row, rowIndex) => (
      <div key={rowIndex} className="seat-row">
        {row.map((seatNumber) => (
          <Seat key={seatNumber} seatNumber={seatNumber} />
        ))}
      </div>
    ));
  };

  return (
    <div className="App">
      <h1>Office Seat Booking</h1>
      <div className="options">
        <label>
          Room Name:
          <input
            type="text"
            placeholder="Enter Room Name"
            value={roomName}
            onChange={(e) => setRoomName(e.target.value)}
          />
        </label>
        <label>
          Rows:
          <input
            type="number"
            value={rows}
            onChange={(e) => setRows(Number(e.target.value))}
          />
        </label>
        <label>
          Columns:
          <input
            type="number"
            value={columns}
            onChange={(e) => setColumns(Number(e.target.value))}
          />
        </label>
        <button onClick={handleCreateRoom}>Add Room</button>
      </div>
      <div className="seat-grid">
        {renderSeatGrid(Array.from({ length: rows }, () => Array(columns).fill(0)))}
      </div>
      {roomInfo && (
        <div className="room-info">
          <h2>Room Information</h2>
          <p>Room Name: {roomInfo.roomName}</p>
          <p>Rows: {roomInfo.rows}</p>
          <p>Columns: {roomInfo.columns}</p>
          <h3>Seat Arrangement:</h3>
          <div className="seat-matrix">
            {roomInfo.seatStructure.map((row, rowIndex) => (
              <div key={rowIndex} className="matrix-row">
                {row.map((seatNumber, colIndex) => (
                  <div key={colIndex} className="matrix-cell">
                    <Seat seatNumber={seatNumber} />
                  </div>
                ))}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default AddRooms;


