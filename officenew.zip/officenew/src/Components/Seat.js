import React from "react";
import { Row,Col, message } from 'antd';
import axios from 'axios';

import { Form,Modal,Button} from 'antd';
import { useDispatch } from "react-redux";
// import { axiosInstance } from "../helpers/axiosInstance";
function Seat(
    {showRoom,setShowRoom,type='add'}
){
// const dispatch=useDispatch();
const onFinish=async(values) =>{
    try{
        let response=null
        if(type==='add'){
            response=await axios.post('http://localhost:5000/api/seates/add-seats', values);
            
        }
        else{
    }
    if (response.data.success){
        message.success(response.data.message);
    }else {
        message.error(response.data.message);
     
    }
    }catch(error){
        message.error(error.message);
        console.log("th")

    }
}
    return (
        <Modal title='Add Room'visible={showRoom} onCancel={()=>setShowRoom(false)} footer={false}>
           
            <Form onFinish={onFinish}>
                <Row>
                    <Col>
                    <Form.Item label="Room Name" name="name">
                        <input type="text"/>
                    </Form.Item>
                    </Col>
                    <Col>
                    <Form.Item label="Room seat" name="seat">
                        <input type="text"/>
                    </Form.Item>
                    </Col>
                </Row>
                <div className="d-flex justify-content-end">
                <button className="addroom"type="submit">Submit</button>
                </div>

            </Form>

        </Modal>
    )
}
export default Seat;
