import { useState } from "react";
import React, { useEffect } from "react";
import { useSelector } from "react-redux";
import axios from "axios";

import { message, Row, Col } from 'antd';
import Seats from '../Components/Seats'



function Home() {
    // const {user}=useSelector(state=>state.users)
 
    const [seates, setSeates] = useState([]);
    const getSeates = async () => {
        try {
            const response = await axios.post("http://localhost:5000/api/seates/get-all-seates", {});
            if (response.data.success) {
                setSeates(response.data.data);
            } else {
                message.error(response.data.message);
            }

        } catch (error) {
            message.error(error, message)
        }
    }
    useEffect(() => {
        getSeates();

    }, [])
    return (
        <div>

            <div>
            <Row>
  {seates.map(seatr => (
    <Col key={seatr.id} lg={12} xs={24} sm={24}>
      <Seats seatr={seatr} />
    </Col>
  ))}
</Row>
            </div>


        </div>
    )
}
export default Home;



