import React, { useEffect, useState } from "react"; // Import useState from React
import Seat from "./Seat";
import axios from "axios";
import { Table, message } from "antd";


function Officeseats() {
    const [showRoom, setShowRoom] = useState(false); // Use useState to define state
    const [seates,setSeates]=useState([]);
    

    const getSeates=async ()=>{
        try{
            const response=await axios.post("http://localhost:5000/api/seates/get-all-seates",{});
            if(response.data.success){
                setSeates(response.data.data);
            }else{
                message.error(response.data.message);
            }
           
        } catch(error){
            message.error(error,message)
        }
    }

    const columns=[
        {
            title:"Room Name",
            dataIndex:"name",
        },
        {
            title:"Room seat",
            dataIndex:"seat",
        },
        // {
        //     title:"Actions",
        //     dataIndex:"action",
        //     render:(action,record)=>(
        //         <div className="d-flex gap-3">
        //             <i class="ri-delete-bin-5-fill"></i>
        //             <i class="ri-pencil-fill"></i>
        //         </div>
        //     )
        // },
    ]
    useEffect(()=>{
        getSeates();

    },[])

    return (
        <div>
            <div className="d-flex justify-content-between">
                <button className="addroom" onClick={() => setShowRoom(true)}>Add Room</button>
            </div>

            <Table
            columns={columns}
            dataSource={seates}
            />
            {showRoom && <Seat showRoom={showRoom} setShowRoom={setShowRoom} type='add' />}
        </div>
    );
}

export default Officeseats;
