import React from 'react';
import '../Styles/userbookstyle.css'; 
import { useNavigate } from 'react-router-dom';

function Seats({ seatr }) {
    const navigate=useNavigate();
  return (
    <div className='card'>
    <h1> {seatr.name}</h1> 
    <hr/>
    <div className='flex justify-between'>
        <div>
            <p className='text-sm'> Room Total Capacity:{seatr.seat}</p>
        </div>
        <h3 className="text-lg underline" onClick={()=>{
            navigate(`/book-now/${seatr.id}`)
        }}>Book Seat</h3>
    </div>
    </div>
  );
}

export default Seats;
