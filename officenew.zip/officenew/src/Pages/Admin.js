import React, { useState, useEffect } from 'react';
import Rooms from '../Components/Rooms';

 // Import your external CSS file



const Admin = () => {

  return (
    <Rooms />
   
  );
};

export default Admin;
