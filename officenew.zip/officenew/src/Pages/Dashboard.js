import React, { useState, useEffect } from 'react';
import UserRoom from '../Components/UserRooms';
import Officeseats from '../Components/officeseat';

 // Import your external CSS file



const Dashboard = () => {

  return (
    <Officeseats/>
   
  );
};

export default Dashboard;
