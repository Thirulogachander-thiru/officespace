import React, { useState, useEffect } from 'react';

import Home from '../Components/Home';

 // Import your external CSS file



const Users = () => {

  return (
    <Home/>
   
  );
};

export default Users;
