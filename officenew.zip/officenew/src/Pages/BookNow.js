// import { useState } from "react";
// import React, { useEffect } from "react";
// import { useSelector } from "react-redux";
// import axios from "axios";

// import { message, Row, Col } from 'antd';
// import { useParams } from "react-router-dom";
// function BookNow() {
//     const [seat, setSeat] = useState(null);
//     const params = useParams();
//     const getSeat = async () => {
//         try {
//             const response = await axios.post("http://localhost:5000/api/seates/get-seat-by-id", {
//                 _id: params.id,
//             });
//             if (response.data.success) {
//                 setSeat(response.data.data);
//             } else {
//                 message.error(response.data.message);
//             }

//         } catch (error) {
//             message.error(error, message)
//         }
//     }
//     useEffect(() => {
//         getSeat();

//     }, [])
//     return (
//         <div>
//        {seat && <Row>
//             <Col lg={12} xs={24} sm={24}>
//                 <h1>{seat.name}</h1>
//                 <hr/>
//             </Col>
//             <Col lg={12} xs={24} sm={24}></Col>
//         </Row>}
//         </div>
//     )
// }
// export default BookNow