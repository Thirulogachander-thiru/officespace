import React from 'react';
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import  Admin  from './Pages/Admin';
import Dashboard from './Pages/Dashboard';
import Users  from './Pages/User';
import BookNow from './Pages/BookNow';

 const App=()=>{
  return (
  <Router>
    <Routes>
    <Route path='/admindashboard' element={<Admin/>}/>
    <Route path='/dashboard' element={<Dashboard/>}/>
    <Route path='/user' element={<Users/>}/>
    <Route path='/book-now/:id' element={<BookNow/>}/>
    </Routes>
  </Router>
 
  );
}

export default App;
