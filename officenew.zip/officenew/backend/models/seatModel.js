const mongoose=require('mongoose');

const seatSchema=new mongoose.Schema({
    name :{
        type:String,
        required:true
    },
    seat:{
        type :Number,
        required:true
    },
    seatsBooked :{
        type : Array,
        default:[]
    },
})

module.exports=mongoose.model('seates',seatSchema);