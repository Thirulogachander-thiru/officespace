const express = require("express")
const cors = require('cors');

const app = express();

// Allow requests from http://localhost:3000
const corsOptions = {
  origin: 'http://localhost:3000',
  methods: 'GET,HEAD,PUT,PATCH,POST,DELETE',
  credentials: true, // Allow cookies to be sent along with the request
  optionsSuccessStatus: 204, // No content response for preflight requests
};

app.use(cors(corsOptions));
require('dotenv').config()
const port=process.env.PORT || 5000;
const dbconfig=require("./config/dbconfig");
app.use(express.json())

const seatRoute=require('../backend/Routers/seatRoute')

app.use(seatRoute)

app.listen(port, () =>
    console.log(`server started ${port}`)
)


