const router=require('express').Router();
const Seat=require("../models/seatModel");
router.post ('/api/seates/add-seats', async (req,res)=>{
    try{
    console.log(req.body)
    const newSeat=new Seat(req.body);
    const response=await newSeat.save();
    console.log(response, 'response')
    return res.status(200).send({
        success:true,
        message:'Seat added successfully',
    })
       
    } catch (error){
        res.status(500).send({
            success:false,
            message:error.message,
        });
    }

});

router.post('/get-all-seates',async (req,res)=>{
    try{
        const seates=await Seat.find();
        return res.status(200).send({
            success:true,
            message:"Seates fetched successfully",
            data:seates,
        });

    } catch (error){
        res.status(500).send({success:false,message:error.message});
    }
})

// router.post('/get-seat-by-id',async (req,res)=>{
//     try{
//         const seat=await Seat.findById(req.body._id);
//         return res.status(200).send({
//             success:true,
//             message:"Seates fetched successfully",
//             data:seat,
//         });

//     } catch (error){
//         res.status(500).send({success:false,message:error.message});
//     }
// })



module.exports=router;